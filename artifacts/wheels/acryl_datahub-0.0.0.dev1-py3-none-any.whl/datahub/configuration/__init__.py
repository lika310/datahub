from datahub.configuration.common import (
    ConfigModel as ConfigModel,
    DynamicTypedConfig as DynamicTypedConfig,
)
