# Datahub Airflow Plugin

See [the DataHub Airflow docs](https://datahubproject.io/docs/lineage/airflow) for details.

## Developing

See the [developing docs](../../metadata-ingestion/developing.md).
